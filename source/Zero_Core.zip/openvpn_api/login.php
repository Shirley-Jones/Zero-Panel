<?php
/*
	ZeroML  版权所有  
*/

	
	
	include("/Zero/Config/system.php");
	
	
	$username = $argv[1];
	$password = $argv[2];
	English_and_Numbers_Check_Json('1','16',$username,'账号');
	English_and_Numbers_Check_Json('1','16',$password,'密码');
	
	
	
	#用户名 密码 

	if(trim($username) == "" || trim($password) == "")
	{
		//账号和密码不能为空！
		die('error');
	}
	
	
	$md5_password = strtoupper(md5($password));
	
	
	//检查请求的节点授权状态
	if(!$Server_Check = db(_Server_)->where(array("server_ip"=>GetRealIP))->find()){
		//服务器未授权
		die('error');
	}
	
	
	
	//判断账号密码和账户状态是否正确   检查是否为主用户
	if($Account_Check = db(_Account_)->where(array("username"=>$username,"password"=>$md5_password,"state"=>"enable"))->find()){
		//检查用户是否已经在线！！！
		if($online_info = db(_Account_acct_)->where(array("username"=>$username,"online"=>"1"))->find()){
			//已在线
			//请求远端主机杀死用户进程    注意   tcp协议 将会直接断开用户   udp协议直接断网而不会断开用户
			//获取远端服务器信息
			if($note_info = db(_Server_)->where(array("server_ip"=>$online_info["server_ip"]))->find()){
				//获取成功   开始请求远端主机杀死用户进程
				$Server_IP = $note_info['server_ip'];
				$Server_Port = $note_info['server_port'];
				$Server_key = $note_info['server_api_key'];
				$Server_openvpn_port = $online_info["openvpn_port"];
				$set_timeout = stream_context_create(array('http'=>array('method'=>"GET",'timeout'=>'5')));  //http请求方式  5秒超时
				file_get_contents('http://'.$Server_IP.':'.$Server_Port.'/api.php?key='.$Server_key.'&action=kill_user&custom_1='.$username.'&custom_2='.$Server_openvpn_port, false, $set_timeout);
				//2022.11.04 BUG修复  确保不出错 检查数据库是否还有用户在线数据 并更新用户数据为不在线
				db(_Account_acct_)->where(array("id"=>$online_info['id'],'online'=>'1'))->update(array('stop_time'=>time(),'online'=>'0'));
			}else{
				//找不到主机信息  拒绝用户连接
				die('error');
			}
		}
		//获取用户信息
		if(!$Account_info = db(_Account_info_)->where(array("username"=>$Account_Check['username']))->find()){
			db(_Account_auth_)->insert(array('username'=>$username,'password'=>$md5_password,"server_ip"=>GetRealIP,"reply"=>"Authentication failed","reason"=>"用户信息获取失败","time"=>time()));
			die('error');
		}
		
		
		//获取用户大区是否存在
		if(!$region_info = db(_Region_)->where(array("id"=>$Account_info['region']))->find()){
			db(_Account_auth_)->insert(array('username'=>$username,'password'=>$md5_password,"server_ip"=>GetRealIP,"reply"=>"Authentication failed","reason"=>"用户大区不存在","time"=>time()));
			die('error');
		}
		
		//验证当前服务器是否与用户大区匹配
		if(!db(_Server_node_)->where(array("server_id"=>$Server_Check['id'],'region'=>$region_info['id']))->find()){
			db(_Account_auth_)->insert(array('username'=>$username,'password'=>$md5_password,"server_ip"=>GetRealIP,"reply"=>"Authentication failed","reason"=>"用户选中的节点不存在于用户所在的大区","time"=>time()));
			die('error');
		}
		
		
		//查询是否激活
		if($Account_Check["activation"] == "0"){
			//未激活
			//获取总天数
			$max_day = time() + round($Account_Check["end_time"] - $Account_Check["start_time"]);
			if(!db(_Account_)->where(array("username"=>$username,'password'=>$md5_password))->update(array('start_time'=>time(),'end_time'=>$max_day,'activation'=>'1'))){
				//die('激活失败，请检查数据库');
				die('error');
			}
		}
		
		//已激活
		
		
		//获取剩余天数
		if($Account_Check["end_time"] - time() < "1"){
			//无可用的剩余天数
			db(_Account_auth_)->insert(array('username'=>$username,'password'=>$md5_password,"server_ip"=>GetRealIP,"reply"=>"Authentication failed","reason"=>"账户中无可用的剩余天数","time"=>time()));
			die('error');
		}
		
		
		//获取剩余流量
		if($Account_Check["maximum_flow"] - round($Account_Check['upload'] + $Account_Check["download"]) < "1"){
			//无可用的剩余流量
			db(_Account_auth_)->insert(array('username'=>$username,'password'=>$md5_password,"server_ip"=>GetRealIP,"reply"=>"Authentication failed","reason"=>"账户中无可用的剩余流量","time"=>time()));
			die('error');
		}
		
		db(_Account_auth_)->insert(array('username'=>$username,'password'=>$md5_password,"server_ip"=>GetRealIP,"reply"=>"Authentication succeeded","reason"=>"验证成功，操作被允许！","time"=>time()));
		//身份验证成功
		die('success');
		
	}else{
		//找不到任何账号或账号被禁用
		db(_Account_auth_)->insert(array('username'=>$username,'password'=>$md5_password,"server_ip"=>GetRealIP,"reply"=>"Authentication failed","reason"=>"账户不存在或已被封禁!!!","time"=>time()));
		die('error');
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	