#!/bin/bash
	#source /etc/openvpn/Zero_Config.conf
	#用户名 密码 远端端口（服务器） 远端IP 本机端口 本机ip 协议
	
	#用户名 username  common_name
	#密码 password
	#openvpn协议 proto_1
	#openvpn配置 分配给用户IP ifconfig_pool_remote_ip   
	#openvpn配置端口  remote_port_1
	#用户设备ip untrusted_ip
	#用户设备端口 untrusted_port
	#用户虚拟pid   daemon_pid
	#上传流量  bytes_received
	#下载流量  bytes_sent
	
	
	#php /Zero/OpenVPN/lib/php/disconnect.php "$common_name" "$bytes_received" "$bytes_sent" "$proto_1" "$ifconfig_pool_remote_ip" "$remote_port_1" "$untrusted_ip" "$untrusted_port" "$daemon_pid"
	
	Disconnect_Status=$(php /etc/openvpn/openvpn_api/api.php disconnect "$common_name" "$bytes_received" "$bytes_sent");
	if [[ "$Disconnect_Status" == "success" ]];then
		exit 0
	else
		exit 1
	fi
	#Disconnect_Status=$(curl -s "${HTTP_Protocol}${Remote_server_address}/openvpn_api/disconnect.php?username=${common_name}&upload=${bytes_received}&download=${bytes_sent}");
	#Disconnect_Status=$(php /Zero/www/Login/disconnect.php "$common_name" "$bytes_received" "$bytes_sent");
	#if [[ "$Disconnect_Status" == "success" ]];then
	#	exit 0;
	#else
	#	exit 1;
	#fi
	
	
	
	
	
	