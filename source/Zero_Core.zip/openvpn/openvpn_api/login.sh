#!/bin/bash
	#source /etc/openvpn/Zero_Config.conf
	#用户名 密码 远端端口（服务器） 远端IP 本机端口 本机ip 协议
	
	#用户名 username
	#密码 password
	#openvpn协议 proto_1
	#openvpn配置 分配给用户IP ifconfig_pool_remote_ip   
	#openvpn配置端口  remote_port_1
	#用户设备ip untrusted_ip
	#用户设备端口 untrusted_port
	#用户虚拟pid   daemon_pid
	
	
	#read Login_Status < <(php /Zero/OpenVPN/lib/php/login.php "$username" "$password")
	
	
	Login_Status=$(php /etc/openvpn/openvpn_api/api.php login "$username" "$password");
	if [[ "$Login_Status" == "success" ]];then
		exit 0
	else
		exit 1
	fi
	
	
	
	#Login_Status=$(curl -s "${HTTP_Protocol}${Remote_server_address}/openvpn_api/login.php?username=${username}&password=${password}");
	#echo "账号：$username 密码：$password 服务器响应：$Login_Status" >> /etc/openvpn/check.log
	#if [[ "$Login_Status" == "success" ]];then
	#	exit 0;
	#else
	#	exit 1;
	#fi
	
	
	
	
	
	
	
	
	