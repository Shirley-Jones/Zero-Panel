#!/bin/bash

	#source /etc/openvpn/Zero_Config.conf
	#用户名  common_name
	#密码  2022.09.03目前未知
	#openvpn协议 proto_1
	#openvpn配置 分配给用户IP ifconfig_pool_remote_ip   
	#openvpn配置端口  remote_port_1
	#用户设备ip untrusted_ip
	#用户设备端口 untrusted_port
	#用户虚拟pid   daemon_pid
	
	
	#php /Zero/OpenVPN/lib/php/connect.php "$common_name" "$proto_1" "$ifconfig_pool_remote_ip" "$remote_port_1" "$untrusted_ip" "$untrusted_port" "$daemon_pid"
	
	Connect_Status=$(php /etc/openvpn/openvpn_api/api.php connect "$common_name" "$proto_1" "$ifconfig_pool_remote_ip" "$remote_port_1" "$untrusted_ip" "$untrusted_port" "$daemon_pid");
	if [[ "$Connect_Status" == "success" ]];then
		exit 0
	else
		exit 1
	fi
	
	#Connect_Status=$(curl -s "${HTTP_Protocol}${Remote_server_address}/openvpn_api/connect.php?username=${common_name}&agreement=${proto_1}&openvpn_ip=${ifconfig_pool_remote_ip}&openvpn_port=${remote_port_1}&user_ip=${untrusted_ip}&user_port=${untrusted_port}&pid=${daemon_pid}");
	#Connect_Status=$(php /Zero/www/Login/connect.php "$untrusted_port" "$daemon_pid");
	#if [[ "$Connect_Status" == "success" ]];then
	#	exit 0;
	#else
	#	exit 1;
	#fi
	
	