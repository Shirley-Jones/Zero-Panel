<?php
	//引入新的操作接口
	require("/Zero/Config/API_Config.php");


	//抑制一些错误
	error_reporting(0);
	
	function English_and_Numbers_Check_Shell($Mix,$Max,$parameter,$msg){
		if (!ctype_alnum($parameter)) {
			//$status['status'] = "error";
			//$status['msg'] = $msg."只能包含英文或数字！";
			//die(json_encode($status));
			//读取旧的数据
			$log_file = file_get_contents(User_Data_Log);
			file_put_contents(User_Data_Log,$log_file.$msg."只能包含英文或数字！111\n");
			die('error');
		}
		
		if(!preg_match('/^[\w\x80-\xff]{'.$Mix.','.$Max.'}$/', $parameter)){
			//$status['status'] = "error";
			//$status['msg'] = $msg."只能是大于".$Mix."位小于".$Max."位的数字或字母！";
			//die(json_encode($status));
			$log_file = file_get_contents(User_Data_Log);
			file_put_contents(User_Data_Log,$log_file.$msg."只能是大于".$Mix."位小于".$Max."位的数字或字母！\n");
			die('error');
		}
	}

switch($argv[1]){
	
	
	
	//用户登录
	case "login" :
		//detected data
		$username = $argv[2];
		$password = $argv[3];
		$API_KEY = API_KEY;
		English_and_Numbers_Check_Shell('5','16',$username,'账号');
		English_and_Numbers_Check_Shell('5','16',$password,'密码');
		English_and_Numbers_Check_Shell('1','16',$API_KEY,'API_KEY');
		//http请求方式  5秒超时
		$Set_Timeout = stream_context_create(array('http'=>array('method'=>"GET",'timeout'=>'5')));  
		//获取数据
		$Get_Data = file_get_contents(HTTP_Protocol.Remote_server_address.'/openvpn_api/login.php?username='.$username.'&password='.$password.'&API_KEY='.$API_KEY, false, $Set_Timeout);
		//解析数据
		$Read_Data = json_decode($Get_Data, true);
		//保存数据
		$log_file = file_get_contents(User_Data_Log);
		file_put_contents(User_Data_Log,$log_file.$Get_Data."\n");
		//返回数据给Shell
		if(strcmp($Read_Data['status'],'success')==0) {
			die('success');
		}else{
			die('error');
		}
	break;
	
	
	//提交用户数据
	case "connect" :
		//detected data
		$username = $argv[2];
		$OpenVPN_agreement = $argv[3];
		$OpenVPN_IP = $argv[4];
		$OpenVPN_Port = $argv[5];
		$User_IP = $argv[6];
		$User_Port = $argv[7];
		$User_PID = $argv[8];
		$API_KEY = API_KEY;
		English_and_Numbers_Check_Shell('5','16',$username,'账号');
		//English_and_Numbers_Check_Shell('5','16',$password,'密码');
		English_and_Numbers_Check_Shell('1','16',$API_KEY,'API_KEY');
		//http请求方式  5秒超时
		$Set_Timeout = stream_context_create(array('http'=>array('method'=>"GET",'timeout'=>'5')));  
		//获取数据
		$Get_Data = file_get_contents(HTTP_Protocol.Remote_server_address.'/openvpn_api/connect.php?username='.$username.'&agreement='.$OpenVPN_agreement.'&openvpn_ip='.$OpenVPN_IP.'&openvpn_port='.$OpenVPN_Port.'&user_ip='.$User_IP.'&user_port='.$User_Port.'&pid='.$User_PID.'&API_KEY='.$API_KEY, false, $Set_Timeout);
		//解析数据
		$Read_Data = json_decode($Get_Data, true);
		//保存数据
		$log_file = file_get_contents(User_Data_Log);
		file_put_contents(User_Data_Log,$log_file.$Get_Data."\n");
		//返回数据给Shell
		if(strcmp($Read_Data['status'],'success')==0) {
			die('success');
		}else{
			die('error');
		}
	break;
	
	
	//用户断开
	case "disconnect" :
		//detected data
		$username = $argv[2];
		$upload = $argv[3];
		$download = $argv[4];
		$API_KEY = API_KEY;
		English_and_Numbers_Check_Shell('5','16',$username,'账号');
		//English_and_Numbers_Check_Shell('5','16',$password,'密码');
		English_and_Numbers_Check_Shell('1','16',$API_KEY,'API_KEY');
		//http请求方式  5秒超时
		$Set_Timeout = stream_context_create(array('http'=>array('method'=>"GET",'timeout'=>'5')));  
		//获取数据
		$Get_Data = file_get_contents(HTTP_Protocol.Remote_server_address.'/openvpn_api/disconnect.php?username='.$username.'&upload='.$upload.'&download='.$download.'&API_KEY='.$API_KEY, false, $Set_Timeout);
		//解析数据
		$Read_Data = json_decode($Get_Data, true);
		//保存数据
		$log_file = file_get_contents(User_Data_Log);
		file_put_contents(User_Data_Log,$log_file.$Get_Data."\n");
		//返回数据给Shell
		if(strcmp($Read_Data['status'],'success')==0) {
			die('success');
		}else{
			die('error');
		}
	break;
	
}