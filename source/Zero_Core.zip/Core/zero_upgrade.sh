#!/bin/bash
#Zero fully automatic upgrade module
#by Shirleylin


Upgrade_Zero()
{
	
	echo "[INFO] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 正在从Zero服务器获取更新脚本 $Project_Name $New_VERSION [$Version_Type]..." >> ${Zero_path}/upgrade/upgrade.log
	curl -o ${Zero_path}/upgrade/upgrade.sh http://${Download_address} >/dev/null 2>&1
	if [ -f ${Zero_path}/upgrade/upgrade.sh ]; then
		get_file_md5=$(md5sum -b ${Zero_path}/upgrade/upgrade.sh | cut -d' ' -f1)
		uppercase_md5=$(echo $get_file_md5 | tr '[:lower:]' '[:upper:]')
		if [[ ${uppercase_md5} == ${zero_md5} ]];then
			#MD5正确  执行脚本
			echo "[INFO] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 脚本已通过验证,开始执行全自动无人值守更新Zero系统,请不要关闭您的服务器." >> ${Zero_path}/upgrade/upgrade.log
			chmod -R 0777 ${Zero_path}/upgrade/upgrade.sh
			${Zero_path}/upgrade/upgrade.sh
			exit 0;
		else
			#不相同
			echo "[ERROR] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 脚本MD5验证失败，文件可能被篡改，请检查您的网络环境." >> ${Zero_path}/upgrade/upgrade.log
			exit 1;
		fi
	else
		echo "[ERROR] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 脚本下载失败，请检查您的网络环境." >> ${Zero_path}/upgrade/upgrade.log
		exit 1;
	fi
	
}




Check_VERSION()
{
	
	if [ ! -d ${Zero_path}/upgrade ]; then
		mkdir ${Zero_path}/upgrade
	else
		rm -rf ${Zero_path}/upgrade/upgrade.txt
		rm -rf ${Zero_path}/upgrade/upgrade.sh
	fi
	
	#检测zero配置文件
	if [ ! -f ${Zero_path}/Config/zero_config.conf ]; then
		echo "[ERROR] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] Zero配置文件不存在,升级程序无法继续." >> ${Zero_path}/upgrade/upgrade.log
		exit 1;
	else
		source ${Zero_path}/Config/zero_config.conf
		if [[ ${Automatic_update} == "true" ]];then
			echo "[INFO] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 正在检测更新,请稍等...." >> ${Zero_path}/upgrade/upgrade.log
		else
			echo "[ERROR] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 因Zero配置文件设置,取消自动更新." >> ${Zero_path}/upgrade/upgrade.log
			exit 0;
		fi
	fi
	
	
	#检测版本号
	if [ ! -f ${Zero_path}/Config/VERSION.conf ]; then
		echo "[ERROR] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 无法检测到您的版本号,升级程序无法继续." >> ${Zero_path}/upgrade/upgrade.log
		exit 1;
	else
		source ${Zero_path}/Config/VERSION.conf
	fi
	
	
	#检测是否需要更新
	curl -o ${Zero_path}/upgrade/upgrade.txt ${Upgrade_API} >/dev/null 2>&1
	if [ ! -f ${Zero_path}/upgrade/upgrade.txt ]; then
		echo "[ERROR] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 配置文件下载失败，请检查您的网络环境." >> ${Zero_path}/upgrade/upgrade.log
		exit 1;
	fi
	
	#版本类型 1
	Version_Type=`cat ${Zero_path}/upgrade/upgrade.txt |grep "${Version_Type}" |grep -v "grep" |awk '{print $1}'`;
	#项目名字 2
	Project_Name=`cat ${Zero_path}/upgrade/upgrade.txt |grep "${Version_Type}" |grep -v "grep" |awk '{print $2}'`;
	#版本号 3
	New_VERSION=`cat ${Zero_path}/upgrade/upgrade.txt |grep "${Version_Type}" |grep -v "grep" |awk '{print $3}'`;
	#下载地址 4
	Download_address=`cat ${Zero_path}/upgrade/upgrade.txt |grep "${Version_Type}" |grep -v "grep" |awk '{print $4}'`;
	#MD5 5
	zero_md5=`cat ${Zero_path}/upgrade/upgrade.txt |grep "${Version_Type}" |grep -v "grep" |awk '{print $5}'`;
	
	# 使用bc工具进行比较，并将结果赋值给result
	result=$(echo "$New_VERSION > $VERSION" | bc -l)
	 
	# 如果result是1，则New_VERSION大于VERSION
	if [ $result -eq 1 ]; then
		echo "[INFO] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] 检测到有新版本，新版本[$New_VERSION] 本地[$VERSION] 即将自动更新...." >> ${Zero_path}/upgrade/upgrade.log
		Upgrade_Zero
		exit 0;
	else
		echo "[INFO] [$(date '+%Y-%m-%d') $(date '+%H:%M:%S')] Zero $VERSION 已经是最新版本." >> ${Zero_path}/upgrade/upgrade.log
		rm -rf ${Zero_path}/upgrade/upgrade.txt
		exit 0;
	fi
	
	
}

Loading()
{
	Zero_path="/Zero";
	OpenVPN_path="/etc/openvpn";
	Trojan_path="/etc/trojan";
	WEB_path="/var/www/html";
	Upgrade_API="http://api.qiaouu.top/shell/zero_resources/upgrade.txt";
	Check_VERSION
	
}


Loading
exit 0;