#!/bin/bash
#ZeroML 自定义开机自启动控制器

sh /Zero/Config/auto_run

exit 0;
