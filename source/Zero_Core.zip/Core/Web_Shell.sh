#!/bin/bash

Action=$1
custom_1=$2
custom_2=$3
custom_3=$4
custom_4=$5




Zero_Kill_User()
{
	if [[ $custom_2 == "tcp-server" ]];then
		agreement="server-tcp";
		agreement_Port="7505";
	else
		if [[ $custom_2 == "udp" ]];then
			agreement="server-tdp";
			agreement_Port="7506";
		else
			echo "error";
			exit 0;
		fi
	fi
	
	#寻找在线用户
	Check_User_Online=`grep "$custom_1" /etc/openvpn/openvpn_log/"$agreement"_online.txt`
	if [ -z "$Check_User_Online" ];then
		#没有找到用户
		echo "error";
		exit 0;
	else
		#用户在线
		/Zero/Core/account-kill $custom_1 $agreement_Port >/dev/null 2>&1
		#sleep 1;
		echo "success";
		exit 0;
	fi
}

case $Action in
	"kill_user")
		Zero_Kill_User
	;;
	
	*) 
		echo "请按照如下命令执行 Web_Shell.sh [kill_user] ";
		exit 0;
    ;;
esac 