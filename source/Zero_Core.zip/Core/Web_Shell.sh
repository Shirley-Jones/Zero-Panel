#!/bin/bash

Action=$1
custom_1=$2
custom_2=$3
custom_3=$4
custom_4=$5




Zero_Kill_User()
{
	if [[ $custom_2 == "1194" ]];then
		configuration_name="server-tcp1194";
		configuration_port="7500";
	elif [[ $custom_2 == "1195" ]];then
		configuration_name="server-tcp1195";
		configuration_port="7501";
	elif [[ $custom_2 == "1196" ]];then
		configuration_name="server-tcp1196";
		configuration_port="7502";
	elif [[ $custom_2 == "1197" ]];then
		configuration_name="server-tcp1197";
		configuration_port="7503";
	elif [[ $custom_2 == "53" ]];then
		configuration_name="server-udp53";
		configuration_port="7504";
	elif [[ $custom_2 == "67" ]];then
		configuration_name="server-udp67";
		configuration_port="7505";
	else
		echo "error";
		exit 0;
	fi
	
	#寻找在线用户
	Check_User_Online=`grep "$custom_1" /etc/openvpn/openvpn_log/"$configuration_name"_online.txt`
	if [ -z "$Check_User_Online" ];then
		#没有找到用户
		echo "error";
		exit 0;
	else
		#用户在线
		/Zero/Core/account-kill $custom_1 $configuration_port >/dev/null 2>&1
		#sleep 1;
		echo "success";
		exit 0;
	fi
}

case $Action in
	"kill_user")
		Zero_Kill_User
	;;
	
	*) 
		echo "请按照如下命令执行 Web_Shell.sh [kill_user] ";
		exit 0;
    ;;
esac 