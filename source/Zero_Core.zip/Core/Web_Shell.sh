#!/bin/bash

Action=$1
custom_1=$2
custom_2=$3
custom_3=$4
custom_4=$5




Zero_Kill_User()
{
	if [[ $custom_2 == "1194" ]];then
		configuration_name="server-tcp1194";
		configuration_port="7500";
	elif [[ $custom_2 == "1195" ]];then
		configuration_name="server-tcp1195";
		configuration_port="7501";
	elif [[ $custom_2 == "1196" ]];then
		configuration_name="server-tcp1196";
		configuration_port="7502";
	elif [[ $custom_2 == "1197" ]];then
		configuration_name="server-tcp1197";
		configuration_port="7503";
	elif [[ $custom_2 == "53" ]];then
		configuration_name="server-udp53";
		configuration_port="7504";
	elif [[ $custom_2 == "67" ]];then
		configuration_name="server-udp67";
		configuration_port="7505";
	else
		echo "error";
		exit 0;
	fi
	
	#寻找在线用户
	Check_User_Online=`grep "$custom_1" /etc/openvpn/openvpn_log/"$configuration_name"_online.txt`
	if [ -z "$Check_User_Online" ];then
		#没有找到用户
		echo "error";
		exit 0;
	else
		#用户在线
		/Zero/Core/account-kill $custom_1 $configuration_port >/dev/null 2>&1
		#sleep 1;
		echo "success";
		exit 0;
	fi
}


Restart_Zero()
{
	echo "success";
	/Zero/bin/zero restart >/dev/null 2>&1
}

Restart_apache()
{
	echo "success";
	systemctl restart apache2.service >/dev/null 2>&1
}

Restart_mysql()
{
	echo "success";
	systemctl restart mariadb.service >/dev/null 2>&1
}

Restart_openvpn()
{
	echo "success";
	systemctl restart server-tcp1194.service >/dev/null 2>&1
	systemctl restart server-tcp1195.service >/dev/null 2>&1
	systemctl restart server-tcp1196.service >/dev/null 2>&1
	systemctl restart server-tcp1197.service >/dev/null 2>&1
	systemctl restart server-udp54.service >/dev/null 2>&1
	systemctl restart server-udp67.service >/dev/null 2>&1
}

Restart_proxy()
{
	echo "success";
	systemctl restart proxy.service >/dev/null 2>&1
}

Restart_rate()
{
	echo "success";
	systemctl restart rate.service >/dev/null 2>&1
}

Restart_zeroauth()
{
	echo "success";
	systemctl restart zero_auth.service >/dev/null 2>&1
}

Restart_reboot()
{
	echo "success";
	reboot
}

Restart_poweroff()
{
	echo "success";
	poweroff
}


case $Action in
	"kill_user")
		Zero_Kill_User
	;;
	
	"zero")
		Restart_Zero
	;;
	
	"apache")
		Restart_apache
	;;
	
	"mysql")
		Restart_mysql
	;;
	
	"openvpn")
		Restart_openvpn
	;;
	
	"proxy")
		Restart_proxy
	;;
	
	"rate")
		Restart_rate
	;;
	
	"zeroauth")
		Restart_zeroauth
	;;
	
	"reboot")
		Restart_reboot
	;;
	
	"poweroff")
		Restart_poweroff
	;;
	
	*) 
		echo "错误，此文件是由Zero Panel使用和管理~";
		exit 0;
    ;;
esac 