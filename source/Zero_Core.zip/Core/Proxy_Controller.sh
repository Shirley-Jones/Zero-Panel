#!/bin/bash
#Zero Proxy服务启动文件


Start_Zero_Proxy()
{
	Load_profile
	
	
	#启动
	if [ ! -f "$Proxy_File" ]; then
		#失败
		echo "$Proxy_Name Binary file does not exist，Please check if the path is correct ($Proxy_File)";
		exit 1;
		#mkdir /Super
	else
		#启动
		cat $Proxy_Port_Config_File | while read line
		do
			port=`echo $line | cut -d \  -f 2`
			$Proxy_File -l $port -d >/dev/null 2>&1
		done
		Check_Proxy_PID=`ps -ef |grep "$Proxy_Name" |grep -v "grep" |awk '{print $2}'`;
		if [[ ! -z ${Check_Proxy_PID} ]]; then
			echo "$Proxy_Name Started....."
		else
			echo "$Proxy_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	exit 0;
	
}

Stop_Zero_Proxy()
{
	Load_profile
	
	
	
	#停止
	killall -9 $Proxy_Name >/dev/null 2>&1
	sleep 3
	echo "$Proxy_Name Stopped....."
	
	
	exit 0;
	
	
	
	
	
}

Restart_Zero_Proxy()
{
	Load_profile
	
	#启动
	if [ ! -f "$Proxy_File" ]; then
		#失败
		echo "$Proxy_Name Binary file does not exist，Please check if the path is correct ($Proxy_File)";
		exit 1;
		#mkdir /Super
	else
		#停止
		killall -9 $Proxy_Name >/dev/null 2>&1
		sleep 3
		echo "$Proxy_Name Stopped....."
		#启动
		cat $Proxy_Port_Config_File | while read line
		do
			port=`echo $line | cut -d \  -f 2`
			$Proxy_File -l $port -d >/dev/null 2>&1
		done
		Check_Proxy_PID=`ps -ef |grep "$Proxy_Name" |grep -v "grep" |awk '{print $2}'`
		if [[ ! -z ${Check_Proxy_PID} ]]; then
			echo "$Proxy_Name Started....."
		else
			echo "$Proxy_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	
	
	exit 0;
	
}


Check_Zero_Proxy_Run()
{
	
	Load_profile
	
	printf "%-70s"  "$Proxy_Name PID"
	Check_Proxy_PID=$(echo `ps -ef |grep "$Proxy_Name" |grep -v "grep" |awk '{print $2}'` | tr -d '\n') 
	if [[ ! -z ${Check_Proxy_PID} ]]; then
		echo -e "[ \033[32m Running \033[0m ]"
	else
		echo -e "[ \033[31m Not running \033[0m ]"
	fi
	
	
	exit 0;
	
}

Load_profile()
{
	Proxy_Port_Config_File="/Zero/Config/Port_List.conf";
	Proxy_File="/Zero/Core/Proxy.bin";
	Proxy_Name="Proxy.bin";
}



case $1 in
	"start")
		Start_Zero_Proxy
	;;
	"restart")
		Restart_Zero_Proxy
	;;
	"stop")
		Stop_Zero_Proxy
	;;	
	"status")
		Check_Zero_Proxy_Run
	;;
	"state")
		Check_Zero_Proxy_Run
	;;
	
	*) 
		echo "Please execute the following command $0 [start|restart|stop|status|state] For example, restart proxy service command $0 restart";
		exit 0;
    ;;
esac 


