#!/bin/bash
#Zero Auth服务启动文件


Start_Zero_Auth()
{
	Load_profile
	
	
	#启动
	if [ ! -f "$Auth_File" ]; then
		#失败
		echo "$Auth_Name Binary file does not exist，Please check if the path is correct ($Auth_File)";
		exit 1;
		#mkdir /Super
	else
		#启动
		sleep 1
		$Auth_File -c $Auth_Port_Config_File >/dev/null 2>&1
		Check_Auth_PID=`ps -ef |grep "$Auth_Name" |grep -v "grep" |awk '{print $2}'`;
		if [[ ! -z ${Check_Auth_PID} ]]; then
			echo "$Auth_Name Started....."
		else
			echo "$Auth_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	exit 0;
	
}

Stop_Zero_Auth()
{
	Load_profile
	
	
	
	#停止
	killall -9 $Auth_Name >/dev/null 2>&1
	echo "$Auth_Name Stopped....."
	
	
	exit 0;
	
	
	
	
	
}

Restart_Zero_Auth()
{
	Load_profile
	
	#启动
	if [ ! -f "$Auth_File" ]; then
		#失败
		echo "$Auth_Name Binary file does not exist，Please check if the path is correct ($Auth_File)";
		exit 1;
		#mkdir /Super
	else
		#停止
		killall -9 $Auth_Name >/dev/null 2>&1
		echo "$Auth_Name Stopped....."
		#启动
		sleep 1
		$Auth_File -c $Auth_Port_Config_File >/dev/null 2>&1
		Check_Auth_PID=`ps -ef |grep "$Auth_Name" |grep -v "grep" |awk '{print $2}'`
		if [[ ! -z ${Check_Auth_PID} ]]; then
			echo "$Auth_Name Started....."
		else
			echo "$Auth_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	
	
	exit 0;
	
}


Check_Zero_Auth_Run()
{
	
	Load_profile
	
	printf "%-70s"  "$Auth_Name PID"
	Check_Auth_PID=$(echo `ps -ef |grep "$Auth_Name" |grep -v "grep" |awk '{print $2}'` | tr -d '\n') 
	if [[ ! -z ${Check_Auth_PID} ]]; then
		echo -e "[ \033[32m Running \033[0m ]"
	else
		echo -e "[ \033[31m Not running \033[0m ]"
	fi
	
	
	exit 0;
	
}

Load_profile()
{
	Auth_Port_Config_File="/Zero/Config/auth_config.conf";
	Auth_File="/Zero/Core/ZeroAUTH.bin";
	Auth_Name="ZeroAUTH.bin";
}



case $1 in
	"start")
		Start_Zero_Auth
	;;
	"restart")
		Restart_Zero_Auth
	;;
	"stop")
		Stop_Zero_Auth
	;;	
	"status")
		Check_Zero_Auth_Run
	;;
	"state")
		Check_Zero_Auth_Run
	;;
	
	*) 
		echo "Please execute the following command $0 [start|restart|stop|status|state] For example, restart auth service command $0 restart";
		exit 0;
    ;;
esac 


