#!/bin/bash

Action=$1
custom_1=$2
custom_2=$3
custom_3=$4
custom_4=$5




Zero_Kill_User()
{
	if [[ $custom_2 == "1194" ]];then
		configuration_name="server-tcp1194";
		configuration_port="7500";
	elif [[ $custom_2 == "1195" ]];then
		configuration_name="server-tcp1195";
		configuration_port="7501";
	elif [[ $custom_2 == "1196" ]];then
		configuration_name="server-tcp1196";
		configuration_port="7502";
	elif [[ $custom_2 == "1197" ]];then
		configuration_name="server-tcp1197";
		configuration_port="7503";
	elif [[ $custom_2 == "53" ]];then
		configuration_name="server-udp53";
		configuration_port="7504";
	elif [[ $custom_2 == "67" ]];then
		configuration_name="server-udp67";
		configuration_port="7505";
	else
		echo "error";
		exit 0;
	fi
	
	#寻找在线用户
	Check_User_Online=`grep "$custom_1" /etc/openvpn/openvpn_log/"$configuration_name"_online.txt`
	if [ -z "$Check_User_Online" ];then
		#没有找到用户
		echo "error";
		exit 0;
	else
		#用户在线
		/Zero/Core/account-kill $custom_1 $configuration_port >/dev/null 2>&1
		#sleep 1;
		echo "success";
		exit 0;
	fi
}
resetiptables()
{
	Read_network_card_information=`ifconfig`;
	Read_main_network_card_information=`echo $Read_network_card_information|awk '{print $1}'`;
	Main_network_card_name=`printf ${Read_main_network_card_information/:/}`
	if [[ ${Main_network_card_name} == "" ]]; then 
		echo "无法获取主网卡信息，强制退出程序!!!"
		exit 1;
	fi
	apt update >/dev/null 2>&1
	apt	install iptables -y >/dev/null 2>&1
	#禁用 firewalld
	systemctl stop firewalld.service >/dev/null 2>&1
	systemctl disable firewalld.service >/dev/null 2>&1
	iptables -P INPUT ACCEPT
	iptables -P FORWARD ACCEPT
	iptables -P OUTPUT ACCEPT
	iptables -t nat -P PREROUTING ACCEPT
	iptables -t nat -P POSTROUTING ACCEPT
	iptables -t nat -P OUTPUT ACCEPT
	iptables -F
	iptables -t nat -F
	iptables -X
	iptables -t nat -X
	iptables -A INPUT -s 127.0.0.1/32  -j ACCEPT
	iptables -A INPUT -d 127.0.0.1/32  -j ACCEPT
	iptables -A INPUT -p tcp -m tcp --dport $SSH_Port -j ACCEPT
	if [ -f "/etc/apache2/ports.conf" ]; then
		#读取配置文件
		Apache_Port=$(grep -E 'Listen [0-9]+$' /etc/apache2/ports.conf | awk '{print $2}' | head -n 1)
		Apache_TrojanWEB_Port=$(grep -E 'Listen [0-9]+$' /etc/apache2/ports.conf | awk '{print $2}' | tail -n 1 | head -n 1)
		iptables -A INPUT -p tcp -m tcp --dport $Apache_Port -j ACCEPT
		iptables -A INPUT -p tcp -m tcp --dport $Apache_TrojanWEB_Port -j ACCEPT
	fi
		
	#proxy端口
	cat /Zero/Config/Port_List.conf | while read Proxy_TCP_Port_List
	do
		Proxy_TCP_Port=`echo $Proxy_TCP_Port_List | cut -d \  -f 2`
		iptables -A INPUT -p tcp -m tcp --dport $Proxy_TCP_Port -j ACCEPT
	done
	
	#openvpn端口
	iptables -A INPUT -p tcp -m tcp --dport 1194 -j ACCEPT
	iptables -A INPUT -p tcp -m tcp --dport 1195 -j ACCEPT
	iptables -A INPUT -p tcp -m tcp --dport 1196 -j ACCEPT
	iptables -A INPUT -p tcp -m tcp --dport 1197 -j ACCEPT
	iptables -A INPUT -p udp -m udp --dport 54 -j ACCEPT
	iptables -A INPUT -p udp -m udp --dport 67 -j ACCEPT
	#trojan
	iptables -A INPUT -p tcp -m tcp --dport 443 -j ACCEPT
	iptables -A INPUT -p tcp -m tcp --dport 80 -j ACCEPT
	iptables -t nat -A POSTROUTING -s 10.0.0.0/24 -o ${Main_network_card_name} -j MASQUERADE
	iptables -t nat -A POSTROUTING -s 10.1.0.0/24 -o ${Main_network_card_name} -j MASQUERADE
	iptables -t nat -A POSTROUTING -s 10.2.0.0/24 -o ${Main_network_card_name} -j MASQUERADE
	iptables -t nat -A POSTROUTING -s 10.3.0.0/24 -o ${Main_network_card_name} -j MASQUERADE
	iptables -t nat -A POSTROUTING -s 10.4.0.0/24 -o ${Main_network_card_name} -j MASQUERADE
	iptables -t nat -A POSTROUTING -s 10.5.0.0/24 -o ${Main_network_card_name} -j MASQUERADEs
	#其他
	iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
	iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
	rm -rf /Zero/iptables/zero_rules.v4
	iptables-save > /Zero/iptables/zero_rules.v4
	
	rm -rf /etc/sysctl.conf
	echo '# by Zero L2TP+PPTP+OpenVPN 
net.ipv4.icmp_echo_ignore_broadcasts=1
net.ipv4.icmp_ignore_bogus_error_responses=1
kernel.msgmnb = 65536
kernel.msgmax = 65536
kernel.shmmax = 68719476736
kernel.shmall = 4294967296
kernel.sysrq = 0
kernel.core_uses_pid = 1
net.ipv4.ip_forward = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.default.accept_source_route = 0
net.bridge.bridge-nf-call-ip6tables = 0
net.bridge.bridge-nf-call-iptables = 0
net.bridge.bridge-nf-call-arptables = 0
net.ipv4.tcp_congestion_control= hybla
net.core.rmem_default = 8388608
net.core.rmem_max = 16777216
net.core.wmem_default = 8388608
net.core.wmem_max = 16777216
net.core.netdev_max_backlog = 32768
net.core.somaxconn = 32768
net.core.optmem_max = 81920
net.ipv4.tcp_wmem = 8192 436600 873200
net.ipv4.tcp_rmem = 32768 436600 873200
net.ipv4.tcp_mem = 94500000 91500000 92700000
net.ipv4.tcp_keepalive_time = 1200
net.ipv4.tcp_keepalive_intvl = 30
net.ipv4.tcp_keepalive_probes = 3
net.ipv4.tcp_sack = 1
net.ipv4.tcp_fack = 1
net.ipv4.tcp_timestamps = 1
net.ipv4.tcp_window_scaling = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_fin_timeout = 30
net.ipv4.ip_local_port_range = 10000  65000
net.ipv4.tcp_max_tw_buckets = 5000
net.ipv4.tcp_max_syn_backlog = 65536
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 2
net.ipv4.tcp_max_orphans = 3276800
net.ipv4.tcp_retries2 = 5
vm.overcommit_memory = 1' > /etc/sysctl.conf
	for each in `ls /proc/sys/net/ipv4/conf/`; do
		echo "net.ipv4.conf.${each}.accept_source_route=0" >> /etc/sysctl.conf
		echo "net.ipv4.conf.${each}.accept_redirects=0" >> /etc/sysctl.conf
		echo "net.ipv4.conf.${each}.send_redirects=0" >> /etc/sysctl.conf
		echo "net.ipv4.conf.${each}.rp_filter=0" >> /etc/sysctl.conf
	done
	chmod -R 0777 /etc/sysctl.conf
	sysctl -p >/dev/null 2>&1
	exit 0;
}

Modify_apache()
{
	if [ -f "/etc/apache2/ports.conf" ]; then
		#读取配置文件
		Apache_Port=$(grep -E 'Listen [0-9]+$' /etc/apache2/ports.conf | awk '{print $2}' | head -n 1)
		sed -i "s/"${Apache_Port}"/"${custom_1}"/g" /etc/apache2/ports.conf
		sed -i "s/"${Apache_Port}"/"${custom_1}"/g" /etc/apache2/sites-available/000-default.conf
		systemctl restart apache2.service
		exit 0;
	else
		exit 0;
	fi
}

Add_tcp()
{
	if [ ! -f /Zero/Core/Proxy.bin ]; then
		echo "操作失败, Proxy.bin文件不存在...";
		exit 1;
	fi
	iptables -A INPUT -p tcp -m tcp --dport $custom_1 -j ACCEPT
	/Zero/Core/Proxy.bin -l $custom_1 -d >/dev/null 2>&1
	echo "port $custom_1 tcp" >> /Zero/Config/Port_List.conf
	
	rm -rf /Zero/iptables/zero_rules.v4
	iptables-save > /Zero/iptables/zero_rules.v4
	exit 0;
}

Add_udp()
{
	iptables -t nat -A PREROUTING -p udp --dport $custom_1 -j REDIRECT --to-ports 54
	
	rm -rf /Zero/iptables/zero_rules.v4
	iptables-save > /Zero/iptables/zero_rules.v4
	exit 0;
}
case $Action in
	"kill_user")
		Zero_Kill_User
	;;
	
	#重置防火墙
	"resetiptables")
		resetiptables
	;;
	
	#修改apache端口
	"Modify_apache")
		Modify_apache
	;;
	
	#添加tcp端口
	"Add_tcp")
		Add_tcp
	;;
	
	#添加udp端口
	"Add_udp")
		Add_udp
	;;
	
	*) 
		echo "错误，此文件是由Zero Panel使用和管理~";
		exit 0;
    ;;
esac 