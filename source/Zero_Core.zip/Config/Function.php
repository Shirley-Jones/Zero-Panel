<?php
/*
	ZeroML  版权所有  
*/
	
	//全局变量
	//接口设置(不会设置的请不要乱动，此处会影响到流控全局设置)
	
	
	function db($dbname){
		//$ddcms = $_SERVER['ddcms']['cfg']['host']['ddcms'];
		$db = new MySQL_Connect($dbname);
		return $db;
	}
	
	function dbstr($dbname){
		$ddcms = $_SERVER['ddcms']['cfg']['host']['ddcms'];
		$db = $ddcms.$dbname;
		return $db;
	}
	
	function html_encode($content,$style=ENT_QUOTES){
		return htmlspecialchars($content,$style);
	}
	
	function html_decode($content,$style=ENT_QUOTES){
		return htmlspecialchars_decode($content,$style);
	}
	
	
	
	function English_and_Numbers_Check_Json($Mix,$Max,$parameter,$msg){
		if (!ctype_alnum($parameter)) {
			$status['status'] = "error";
			$status['msg'] = $msg."只能包含英文或数字！";
			die(json_encode($status));
		}
		
		if(!preg_match('/^[\w\x80-\xff]{'.$Mix.','.$Max.'}$/', $parameter)){
			$status['status'] = "error";
			$status['msg'] = $msg."只能是大于".$Mix."位小于".$Max."位的数字或字母！";
			die(json_encode($status));
		}
	}
	
	function Email_Check_Json($parameter){
		if (!filter_var($parameter, FILTER_VALIDATE_EMAIL)){
			$status['status'] = "error";
			$status['msg'] = "邮箱格式不正确！";
			die(json_encode($status));
		}
	}
	
	
	function Chinese_Json($parameter,$msg){
		if(!preg_match("/[\x{4e00}-\x{9fa5}\w\-_]+/u", $parameter)){
			$status['status'] = "error";
			$status['msg'] = $msg."只能包含中文和英文！";
			die(json_encode($status));
		}
	}


