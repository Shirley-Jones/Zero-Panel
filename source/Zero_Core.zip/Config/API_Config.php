<?php
/*
	ZeroML  版权所有  
*/
	
	//远程shell通讯密码
	define("API_KEY","Communication_password");
	//Zero二进制文件位置
	define("Web_Shell","/Zero/Core/Web_Shell.sh");
	//HTTP协议
	define("HTTP_Protocol","http://");
	//主机IP（域名）
	define("Remote_server_address","API_ADDRESS");
	//与主机通讯的所有日志
	define("User_Data_Log","/etc/openvpn/openvpn_log/user_data_log.log");
	//超时时间（秒）
	define("Timeout","5");
	