<?php
/*
	ZeroML  版权所有  
*/
	
	//远程shell通讯密码
	define("API_KEY","content1");
	//Zero二进制文件位置
	define("Web_Shell","/Zero/Core/Web_Shell.sh");
	
	
	