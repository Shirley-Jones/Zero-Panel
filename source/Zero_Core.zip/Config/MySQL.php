<?php
/*
	ZeroML  版权所有  
*/


/*
	请填写你的数据库信息（支持云数据库, 仅支持MySQL5.5 - 5.7 其他版本可能会报错!!!）
*/


define("MySQL_Host","content1");
define("MySQL_Port","content2");
define("MySQL_User","content3");
define("MySQL_Pass","content4");
define("MySQL_DB","zero");
define("MySQL_Charset","utf8mb4");

//数据表
define("_Account_","account");
define("_Account_rate_","account_rate");
define("_Account_acct_","account_acct");
define("_Account_auth_","account_auth");
define("_Account_info_","account_info");
define("_Activation_code_","activation_code");
define("_Activation_code_package_","activation_code_package");
define("_Announcement_","announcement");
define("_App_Download_","app_download");
define("_Line_","line");
define("_Line_feedback_","line_feedback");
define("_Line_type_","line_type");
define("_Map_","map");
define("_Recharge_log_","recharge_log");
define("_Region_","region");
define("_Server_","server");
define("_Server_node_","server_node");
define("_Server_port_","server_port");
define("_Login_log_","login_log");
define("_Zero_admin_","zero_admin");


//其他
define("GetRealIP","content5");








