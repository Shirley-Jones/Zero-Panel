<?php
/*
	ZeroML  版权所有  
*/
	
	//全局变量
	//接口设置(不会设置的请不要乱动，此处会影响到流控全局设置)
	
	
	function db($dbname){
		//$ddcms = $_SERVER['ddcms']['cfg']['host']['ddcms'];
		$db = new MySQL_Connect($dbname);
		return $db;
	}
	
	function dbstr($dbname){
		$ddcms = $_SERVER['ddcms']['cfg']['host']['ddcms'];
		$db = $ddcms.$dbname;
		return $db;
	}
	
	function html_encode($content,$style=ENT_QUOTES){
		return htmlspecialchars($content,$style);
	}
	
	function html_decode($content,$style=ENT_QUOTES){
		return htmlspecialchars_decode($content,$style);
	}
	
	function Username_and_password_Check($parameter) {
		// 用户名密码长度限制
		$Minimum_length = 4; // 最小长度
		$Maximum_length = 20; // 最大长度

		// 检查是否符合长度要求，并且只包含字母、数字和下划线（单字节字符）
		// 如果需要支持多字节字符，请调整正则表达式
		if (!preg_match('/[\w\x80-\xff]{' . $Minimum_length . ',' . $Maximum_length . '}$/', $parameter)) {
			return false;
		}
		return true;
	}
	
	function English_and_Numbers_Check($parameter){
		if (!ctype_alnum($parameter)) {
			return false;
		}
		return true;
	}
	
	function Numbers_Check($parameter){
		if (!ctype_digit($string)) {
			return false;
		}
		return true;
	}
	
	//特殊字符检测
	function Detect_specific_strings($parameter) {
		// 使用 strpos 检测特定的子字符串
		$dangerousSubstrings = [
		'?',
		'script',
		'<',
		'>', 
		'echo', 
		'mysql', 
		'html', 
		'$',
		'require',
		'if',
		'else',
		'fi',
		'POST',
		'GET',
		'username',
		'password',
		'php',
		'api',
		'new',
		'(',
		')',
		'[',
		']',
		'习',
		'近平',
		'习近平',
		'温家宝',
		'拜登',
		'川普',
		'特朗普',
		'Trump',
		'Biden',
		'独',
		'QQ群',
		'民进党',
		'蔡英文',
		'蔡',
		'英文',
		'ing-wen',
		'毛',
		'泽东',
		'毛泽东',
		'普京',
		',',
		';',
		':',
		'"',
		"'",
		'|',
		'\\',
		'/',
		'*',
		'die',
		'exit',
		'foreach',
		'as',
		'strpos',
		'json',
		'static',
		'private',
		'class',
		'try',
		'construct',
		'null',
		'sql',
		'SQL',
		'function',
		'INSERT',
		'strtoupper',
		'array',
		'stream_context_create',
		'file_get_contents',
		'implode',
		'exec',
		'shell',
		'=',
		'+',
		'!',
		'decode',
		'encode',
		'_',
		'&'
		//其他字符待添加...
		];
		foreach ($dangerousSubstrings as $substring) {
			if (strpos($parameter, $substring) !== false) {
				return false;
			}
		}
		return true;
	}


