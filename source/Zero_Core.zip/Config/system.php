<?php
/*
	ZeroML  版权所有  
*/


set_time_limit(0);
error_reporting(0);
//强制使用中国（上海）时区
date_default_timezone_set('Asia/Shanghai');
define('Zero_Config','/Zero/Config');
require(Zero_Config.'/MySQL.php');
require(Zero_Config.'/MySQL_Connect.Class.php');
require(Zero_Config.'/Global_Configuration.php');
require(Zero_Config.'/SqlBase.Class.php');
session_start();
//全局SQL注入
SqlBase::_deal();


