<?php
//include(dirname(dirname(__FILE__))."/system.php");
require('/Zero/Config/API_Config.php');

//$cmd = $_GET["cmd"];

//为了系统安全，只能执行vpn命令!!!

//kill_user

//chown -R "apache:apache" /usr/bin/grep


$action = $_GET['action'] ?: $argv[1];  //kill_user
$custom_1 = $_GET['custom_1'] ?: $argv[2];   //admin
$custom_2 = $_GET['custom_2'] ?: $argv[3];   //openvpn端口
$key = $_GET['key'] ?: $argv[4];   //为了系统安全，需要密钥进行身份验证!!!

	
switch ($action) {
	case 'kill_user':
		//$md5_key = md5($key);
		if(strcmp($key,API_KEY)==0) {
			//相等
			$System_Shell = exec(Web_Shell.' '.$action.' '.$custom_1.' '.$custom_2);
			if(strcmp($System_Shell,'success')==0) {
				die('success');
			}else{
				die('error');
			}
		}else{
			die('身份验证失败!!!');
		}
    break; 
	
	case 'Query_online':
		if(strcmp($key,API_KEY)==0) {
			//相等
			$vpnfilename = '/etc/openvpn/openvpn_log/server-'.$custom_1.'_online.txt'; // 指定要读取的文件的路径
				// 读取文件内容
				$vpnfileContent = file_get_contents($vpnfilename);
				if ($vpnfileContent !== false) {
					// 读取成功，处理文件内容
					//echo $vpnfileContent;
					$vpnonlinenum = (substr_count($vpnfileContent,date('Y'))-1)/2;
					die('<font>'.(int)$vpnonlinenum.'</font>');
				} else {
					// 读取失败，处理错误
					echo "无法读取文件: " . $vpnfilename;
				}
		}else{
			die('身份验证失败!!!');
		}
    break; 
	
	
	
	
	case '':
		die('不支持的操作!!!');
    break; 
	
	
	
	die('不支持的操作!!!');
}











