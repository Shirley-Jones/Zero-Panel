<?php
require('/Zero/Config/API_Config.php');
require('/Zero/Config/Global_Configuration.php');

$action = $_GET['action'] ?: $argv[1];  //kill_user
$custom_1 = $_GET['custom_1'] ?: $argv[2];   //admin
$custom_2 = $_GET['custom_2'] ?: $argv[3];   //openvpn端口
$key = $_GET['key'] ?: $argv[4];   //为了系统安全，需要密钥进行身份验证!!!

if(!Detect_specific_strings($action)){
	//action参数检测到非法字符，请重新尝试~
	die('error -1');
}

if(!Detect_specific_strings($custom_1)){
	//custom_1参数检测到非法字符，请重新尝试~
	die('error -2');
}

if(!Detect_specific_strings($custom_2)){
	//custom_2参数检测到非法字符，请重新尝试~
	die('error -3');
}

if(!Detect_specific_strings($key)){
	//密钥检测到非法字符，请重新尝试~
	die('error -4');
}

if(!English_and_Numbers_Check($key)){
	//密钥只能包含英文和数字~
	die('error -5');
}

if(!strcmp($key,API_KEY)==0) {
	die('身份验证失败!!!');
}

switch ($action) {
	case 'kill_user':
		//相等
		$System_Shell = exec(Web_Shell.' '.$action.' '.$custom_1.' '.$custom_2);
		if(strcmp($System_Shell,'success')==0) {
			die('success');
		}else{
			die('error');
		}
    break; 
	
	case 'Query_online':
		//相等
		$vpnfilename = '/etc/openvpn/openvpn_log/server-'.$custom_1.'_online.txt'; // 指定要读取的文件的路径
		// 读取文件内容
		$vpnfileContent = file_get_contents($vpnfilename);
		if ($vpnfileContent !== false) {
			// 读取成功，处理文件内容
			//echo $vpnfileContent;
			$vpnonlinenum = (substr_count($vpnfileContent,date('Y'))-1)/2;
			die('<font>'.(int)$vpnonlinenum.'</font>');
		}else{
			// 读取失败，处理错误
			echo "无法读取文件: " . $vpnfilename;
		}
    break; 
	
	
	//网速
	case "bwi":
		if(is_file("/Zero/rate.d/minute.json")){
			$json = file_get_contents("/Zero/rate.d/minute.json");
			$data = json_decode($json,true);
			$dataNums = count($data);
			if($dataNums > 0){
				foreach($data as $key=>$vo){
					$bw = $vo["tx"]*80/1024/1024*2;
				}
				die(round($bw,2));
			}			
		}
		die("0");
	break;
	
	//cpu
	case "bwc":
		exec("top -bn1 | grep Cpu",$cpuinfo);
		preg_match('/\s*([0-9\.]*)\s*id/is',$cpuinfo[0],$cpuinfo_free);
		$lyl = 100-(float)$cpuinfo_free[1];
		die($lyl);
	break;
	
	//内存
	case "bwm":
		$memoryInfo = getMemoryInfo();
		// 总内存（单位：KB）
		$totalMemory = (int) filter_var($memoryInfo['MemTotal'], FILTER_SANITIZE_NUMBER_INT);

		// 已使用内存（单位：KB）
		$usedMemory = (int) filter_var($memoryInfo['MemTotal'] - $memoryInfo['MemFree'] - $memoryInfo['Buffers'] - $memoryInfo['Cached'], FILTER_SANITIZE_NUMBER_INT);
		
		$info['status'] = "success";
		$info['totalMemory'] = round($totalMemory / 1024/1024,2);
		$info['usedMemory'] = round($usedMemory / 1024/1024,2);
		die(json_encode($info));
	break;
	
	
	case 'zero':
		if(Socket_Shell("zero restart")) {
			$info['status'] = "success";
			$info['msg'] = "操作已完成";
			die(json_encode($info));
		}else{
			$info['status'] = "error";
			$info['msg'] = "未知错误~";
			die(json_encode($info));
		}
    break; 
	
	
	case 'apache':
		if(Socket_Shell("systemctl restart apache2.service")) {
			$info['status'] = "success";
			$info['msg'] = "操作已完成";
			die(json_encode($info));
		}else{
			$info['status'] = "error";
			$info['msg'] = "未知错误~";
			die(json_encode($info));
		}
    break; 
	
	case 'mysql':
		if(Socket_Shell("systemctl restart mariadb.service")) {
			$info['status'] = "success";
			$info['msg'] = "操作已完成";
			die(json_encode($info));
		}else{
			$info['status'] = "error";
			$info['msg'] = "未知错误~";
			die(json_encode($info));
		}
    break; 
	
	case 'openvpn':
		// 定义要执行的命令
		$commands = [
			"systemctl restart openvpn@server-tcp1194.service",
			"systemctl restart openvpn@server-tcp1195.service",
			"systemctl restart openvpn@server-tcp1196.service",
			"systemctl restart openvpn@server-tcp1197.service",
			"systemctl restart openvpn@server-udp54.service",
			"systemctl restart openvpn@server-udp67.service"
		];

		// 初始化一个标志变量，用于记录所有命令是否都成功
		$all_success = true;

		// 遍历命令数组并执行每个命令
		foreach ($commands as $command) {
			if (!Socket_Shell($command)) {
				// 如果有任何一个命令失败，则将标志变量设置为 false
				$all_success = false;
				break; // 可选：如果只需要知道是否有一个失败，可以在这里停止循环
			}
		}

		// 判断所有命令是否都成功
		if ($all_success) {
			$info['status'] = "success";
			$info['msg'] = "操作已完成";
			die(json_encode($info));
		}else{
			$info['status'] = "error";
			$info['msg'] = "未知错误~";
			die(json_encode($info));
		}
    break; 
	
	case 'proxy':
		if(Socket_Shell("systemctl restart proxy.service")) {
			$info['status'] = "success";
			$info['msg'] = "操作已完成";
			die(json_encode($info));
		}else{
			$info['status'] = "error";
			$info['msg'] = "未知错误~";
			die(json_encode($info));
		}
    break; 
	
	case 'rate':
		if(Socket_Shell("systemctl restart rate.service")) {
			$info['status'] = "success";
			$info['msg'] = "操作已完成";
			die(json_encode($info));
		}else{
			$info['status'] = "error";
			$info['msg'] = "未知错误~";
			die(json_encode($info));
		}
    break; 
	
	case 'zeroauth':
		if(Socket_Shell("systemctl restart zero_auth.service")) {
			$info['status'] = "success";
			$info['msg'] = "操作已完成";
			die(json_encode($info));
		}else{
			$info['status'] = "error";
			$info['msg'] = "未知错误~";
			die(json_encode($info));
		}
    break; 
	
	case 'reboot':
		$info['status'] = "success";
		$info['msg'] = "操作已完成";
		echo json_encode($info);
		Socket_Shell("reboot");
		exit;
    break; 
	
	case 'poweroff':
		$info['status'] = "success";
		$info['msg'] = "操作已完成";
		echo json_encode($info);
		Socket_Shell("poweroff");
		exit;
    break; 
	
	
	case '':
		die('不支持的操作!!!');
    break; 
	
	
	
	die('不支持的操作!!!');
}











