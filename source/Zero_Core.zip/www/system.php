<?php
/*
	ZeroML  版权所有  
*/

// 检查PHP版本是否为7.X
if (PHP_VERSION_ID < 70000 || PHP_VERSION_ID >= 80000) {
    // 如果版本不是PHP 7.X，输出错误消息并终止脚本执行
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Error: This program can only run under PHP 7.X version.' . PHP_EOL;
    echo 'Current PHP version: ' . phpversion() . PHP_EOL;
    exit(1); // 退出状态码1表示错误
}

set_time_limit(0);
error_reporting(0);
//强制使用中国（上海）时区
date_default_timezone_set('Asia/Shanghai');
define('Zero_Config','/Zero/www/Config');
define('Zero_Core','/Zero/www/Core');
require(Zero_Config.'/API_Config.php');
require(Zero_Config.'/MySQL.php');
require(Zero_Core.'/MySQL_Connect.Class.php');
require(Zero_Core.'/Global_Configuration.php');
require(Zero_Core.'/SqlBase.Class.php');
session_start();
//全局SQL注入
SqlBase::_deal();
