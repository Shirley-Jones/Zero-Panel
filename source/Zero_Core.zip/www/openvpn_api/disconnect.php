<?php
/*
	ZeroML  版权所有  
*/

	include("/Zero/www/system.php");
	
	
	$username = $argv[1];
	$upload = $argv[2];
	$download = $argv[3];
	if(!Detect_specific_strings($username)){
		//账号检测到非法字符，请重新尝试~
		die('error');
	}
	
	if(!Username_and_password_Check($username)){
		//账号只能包含英文和数字，并且长度不能低于4位高于16位字符~
		die('error');
	}
	
	#用户名 密码 远端端口（服务器） 远端IP 本机端口 本机ip 协议

	if(trim($username) == "")
	{
		//账号不能为空
		die('error');
	}
	
	//检查请求的节点授权状态
	if(!$Server_Check = db(_Server_)->where(array("server_ip"=>GetRealIP))->find()){
		//服务器没有授权
		die('error');
	}
	
	
	//判断账号密码和账户状态是否正确 
	if($Account_Check = db(_Account_)->where(array("username"=>$username))->find()){
		//查询是否被禁用
		if(!$Account_Check["state"] == "enable"){
			die('error');
		}
		$new_upload = $Account_Check['upload'] + $upload;
		$new_download = $Account_Check['download'] + $download;
		$Account_info = db(_Account_info_)->where(array("username"=>$Account_Check['username']))->find();
		db(_Account_)->where(array("username"=>$Account_Check['username']))->update(array('upload'=>$new_upload,'download'=>$new_download));
		db(_Account_acct_)->where(array("username"=>$Account_Check['username'],"start_time"=>$Account_info['last_online_time'],"online"=>"1"))->update(array("stop_time"=>time(),'upload'=>$upload,'download'=>$download,"online"=>"0"));
		//更新用户数据并且更新排行榜数据
		$c = $upload+$download;
		$u = db(_Account_rate_)->where(array('username'=>$username,'time'=>date('Y-m-d',time())))->find();
		if($u){
			$new = $u['data']+$c;
			db(_Account_rate_)->where(array('id'=>$u['id']))->update(array('data'=>$new));
		}else{
			db(_Account_rate_)->insert(array('username'=>$username,'data'=>$c,'time'=>date('Y-m-d',time())));
		}
		die('success');
	}else{
		//找不到任何账号或账号被禁用
		die('error');
	}
	
	




