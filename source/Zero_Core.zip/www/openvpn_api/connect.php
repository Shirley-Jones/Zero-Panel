<?php
/*
	ZeroML  版权所有  
*/

	include("/Zero/www/system.php");
	
	
	$username = $argv[1];
	$OpenVPN_agreement = $argv[2];
	$OpenVPN_IP = $argv[3];
	$OpenVPN_Port = $argv[4];
	$User_IP = $argv[5];
	$User_Port = $argv[6];
	$User_PID = $argv[7];
	
	if(!Detect_specific_strings($username)){
		//账号检测到非法字符，请重新尝试~
		die('error');
	}
	
	if(!Username_and_password_Check($username)){
		//账号只能包含英文和数字，并且长度不能低于4位高于16位字符~
		die('error');
	}
	
	//解密数据
	
	if(trim($username) == "")
	{
		//账号不能为空
		die('error');
	}
	
	
	
	//检查请求的节点授权状态
	if(!$Server_Check = db(_Server_)->where(array("server_ip"=>GetRealIP))->find()){
		//服务器没有授权
		die('error');
	}
	
	//判断账号密码和账户状态是否正确 
	if($Account_Check = db(_Account_)->where(array("username"=>$username))->find()){
		//查询是否被禁用
		if(!$Account_Check["state"] == "enable"){
			die('error');
		}
		db(_Account_info_)->where(array("username"=>$username))->update(array('last_online_time'=>time()));
		db(_Account_acct_)->insert(array('username'=>$username,'start_time'=>time(),'stop_time'=>NULL,'upload'=>"0",'download'=>"0",'server_ip'=>GetRealIP,'agreement'=>$OpenVPN_agreement,'openvpn_ip'=>$OpenVPN_IP,'openvpn_port'=>$OpenVPN_Port,'user_ip'=>$User_IP,'user_port'=>$User_Port,'pid'=>$User_PID,'online'=>'1'));
		die('success');
	}else{
		//找不到任何账号或账号被禁用
		die('error');
	}
	