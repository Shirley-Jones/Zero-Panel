<?php
/*
	ZeroML  版权所有  
*/
	
	//远程shell通讯密码
	define("API_KEY","content1");
	//断开用户shell脚本
	define("WEB_Tools","/Zero/Core/WEB_Tools.sh");
	
	
	