<?php
/*
	ZeroML  版权所有  
*/
	
	function db($dbname){
		$db = new MySQL_Connect($dbname);
		return $db;
	}
	
	function unsetLine($arr){
		foreach($arr as $v){
			if(strpos($v,"apache") === 0){
				
			}else{
				$line[] = $v;
			}
		}
		return $line;
	}
	
	function Socket_Shell($content){
		$service_port = 8989;
		$address = '127.0.0.1';
		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		if ($socket === false) {
			socket_close($socket);
			return false;
		}else{
			socket_set_option($socket,SOL_SOCKET,SO_RCVTIMEO,array("sec"=>10, "usec"=>0 ) );
			socket_set_option($socket,SOL_SOCKET,SO_SNDTIMEO,array("sec"=>10, "usec"=>0 ) );
			$result = socket_connect($socket, $address, $service_port);
			if($result === false) {
				socket_close($socket);
				return false;
			}else{
				socket_write($socket, $content, strlen($content));
				socket_read($socket, 8192);
				socket_close($socket);
				return true;
			}
		}
	}

	
	function getMemoryInfo() {
		$data = file_get_contents('/proc/meminfo');
		$memoryInfo = array();
		$lines = explode("\n", $data);
		
		foreach ($lines as $line) {
			list($key, $val) = explode(":", $line);
			$memoryInfo[$key] = trim($val);
		}
		
		return $memoryInfo;
	}
	
	function Username_and_password_Check($parameter) {
		// 用户名密码长度限制
		$Minimum_length = 4; // 最小长度
		$Maximum_length = 20; // 最大长度
		
		if (!preg_match('/[\w\x80-\xff]{' . $Minimum_length . ',' . $Maximum_length . '}$/', $parameter)) {
			return false;
		}
		return true;
	}
	
	function English_and_Numbers_Check($parameter){
		if (!ctype_alnum($parameter)) {
			return false;
		}
		return true;
	}
	
	function Numbers_Check($parameter){
		if (!ctype_digit($string)) {
			return false;
		}
		return true;
	}
	
	//特殊字符检测
	function Detect_specific_strings($parameter) {
		// 使用 strpos 检测特定的子字符串
		$dangerousSubstrings = [
		'?',
		'<',
		'>',
		'$',
		'(',
		')',
		'[',
		']',
		',',
		';',
		':',
		'"',
		"'",
		'|',
		'\\',
		'/',
		'*',
		'=',
		'+',
		'!',
		'&'
		//其他字符待添加...
		];
		foreach ($dangerousSubstrings as $substring) {
			if (strpos($parameter, $substring) !== false) {
				return false;
			}
		}
		return true;
	}


